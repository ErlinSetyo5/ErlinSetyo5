# siakad-laravel (progress)
# Sistem Informasi Akademik
> - Framework : Laravel 5.7
> - Package : [
        1 . yajra-dataTables, 
         2. Laravel-collective
]
> - template : AdminLTE

gunakan seeder untuk register (sementara)
